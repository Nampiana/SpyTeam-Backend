const express = require("express");
const { spawn, exec } = require("child_process");
const http = require("http");
const socketIo = require("socket.io-client");
const os = require("os");
const fs = require("fs"); 
const { app, screen, powerMonitor } = require("electron");
const dotenv = require("dotenv");
dotenv.config({path: "./config.env"})
const appli = express();
const server = http.createServer(appli);
let ffmpeg; // Stocke le processus FFmpeg pour le redémarrer si besoin
let io;
const PORT = 4000;
const serveurBackend = "http://192.168.1.197:5000";
let idClient = "123";

const helper = require("./helper/helper");
let fileName = helper.generateFileName(idClient);
let dateFolder = helper.generateDate();
let isConnected = true;
let resolution = "1280x720"; // Valeur par défaut

function startCapture() {
  const platform = os.platform();

  if (platform == "win32") {
    var capture = "gdigrab";        // Capture d'écran sous Windows avec gdigrab
    var fps = 25;                   // Taux d'images par seconde
    var resolution = "1920x1080";   // Résolution de capture
    var captureOs = "desktop";      // Source (capture de l'écran)
    var qualite = 31;               // Qualité vidéo (1 à 31, 5 est généralement bon)
    var format = "mp4";             // Format de sortie
    
    var ffmpeg = spawn("ffmpeg", [
      "-f", capture,                // Capture d'écran sous Windows avec gdigrab
      "-r", fps.toString(),         // Taux d'images par seconde (doit être converti en chaîne)
      "-s", resolution,             // Résolution de capture
      "-i", captureOs,              // Source (capture de l'écran)
      "-q:v", qualite.toString(),   // Qualité vidéo (1 à 31, 5 est généralement bon)
      "-c:v", "libx264",            // Codec vidéo
      "-preset", "veryfast",        // Préréglage de l'encodage
      "-crf", "23",                 // Valeur du CRF (qualité de la vidéo, 0 = meilleure qualité, 51 = la pire)
      "-pix_fmt", "yuv420p",        // Format de pixel pour la compatibilité
      "-movflags", "frag_keyframe+empty_moov", // Paramètres pour les fichiers MP4 compatibles
      "-f", format,                 // Format de sortie
      "pipe:1",                     // Sortie via un flux
    ]);
  }
  if (platform == "linux") {
    const capture = "x11grab";
    const fps = "25";
    const captureOs = ":0.0";
    const qualite = "31";
    const format = "avi";
    var ffmpeg = spawn("ffmpeg", [
      "-f",capture, // Capture écran (Linux)
      "-r",fps, // Taux d'images par seconde
      "-s",resolution, // Résolution
      "-i",captureOs, // Capture de l'écran (Linux)
      "-q:v",qualite, // Qualité vidéo (valeur de 1 à 31, 5 est généralement bon)
      "-f",format, // Format de sortie MJPEG
      "pipe:1", // Sortie via un flux
    ]);
  }

  ffmpeg.stdout.on("data", (data) => {
    if (io) io.emit("video", { data, client: idClient, fileName: fileName });
  });
}

// Fonction pour arrêter FFmpeg
function stopCapture() {
  if (ffmpeg) {
    ffmpeg.kill("SIGTERM");
    ffmpeg = null;
  }
}

// Fonction pour redémarrer FFmpeg
function restartCapture() {
  fileName = helper.generateFileName(idClient);
  io.emit("sendVideo", { client: idClient, fileName: fileName, dateFolder:dateFolder });
  startCapture();
}

// Gestion de la mise en veille et du réveil
app.whenReady().then(() => {
  const displays = screen.getAllDisplays();
  let totalWidth = 0,
    totalHeight = 0;

  displays.forEach((display) => {
    totalWidth += display.bounds.width;
    totalHeight = Math.max(totalHeight, display.bounds.height);
  });

  resolution = `${totalWidth}x${totalHeight}`;

  io = socketIo(serveurBackend);
  io.on("connect", () => {
    io.emit("sendVideo", { client: idClient, fileName: fileName, dateFolder:dateFolder });
  });

  startCapture(); // Démarrer la capture dès le lancement

  server.listen(PORT, () => {
    console.log("serveur running on port "+PORT);    
  });
});

// Vérifier si l'ordinateur est toujours en ligne
function checkConnection() {
  exec("ping -c 1 google.com", (error) => {
    if (error) {
      if (isConnected) {        
        isConnected = false;
      }
    } else {
      if (!isConnected) {        
        isConnected = true;
        startCapture();
      }
    }
  });
}

powerMonitor.on("suspend", () => {
  stopCapture();
});

powerMonitor.on('lock-screen', () => {
  stopCapture();
})

powerMonitor.on('unlock-screen', () => {  
  restartCapture();
})

setInterval(checkConnection, 5000);
