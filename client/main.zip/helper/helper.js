const generateFileName = (idClient) =>{
    const date = new Date();

    const dateString = date.toLocaleString("fr-FR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
    });

    const fileName = `capture_${dateString
        .replace(/\//g, "-")
        .replace(/:/g, "-")}_${idClient}.mp4`;

    return fileName;
}

const generateDate = () =>{
    const date = new Date();

    const dateString = date.toLocaleString("fr-FR", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    });
    const folderName = `${dateString
        .replace(/\//g, "-")
        .replace(/:/g, "-")}`;

    return folderName;
}


module.exports = {generateFileName, generateDate};